// Copyright (c) 2019-present, Facebook, Inc.
// All rights reserved.
//
// This source code is licensed under the license found in the
// LICENSE file in the root directory of this source tree.
//

#include <iostream>
#include <cstdlib>
#include <string>
#include <vector>
#include <fstream>
#include <iomanip>
#include <bits/stdc++.h>
using namespace std;
unsigned int f_gold ( unsigned int n ) {
  n --;
  n |= n >> 1;
  n |= n >> 2;
  n |= n >> 4;
  n |= n >> 8;
  n |= n >> 16;
  n ++;
  return n;
}


unsigned int f_filled ( unsigned int n ) {
  n -= 1U ;
  n |= n >> 1U ;
  n |= n >> 2U ;
  n |= n >> 4U ;
  n |= n >> 8U ;
  n |= n >> 16U ;
  n += 1U ;
}

int main() {
    int n_success = 0;
    vector<int> param0 {63,78,13,5,34,69,63,78,80,19};
    for(int i = 0; i < param0.size(); ++i)
    {
        if(f_filled(param0[i]) == f_gold(param0[i]))
        {
            n_success+=1;
        }
    }
    cout << "#Results:" << " " << n_success << ", " << param0.size();
    return 0;
}