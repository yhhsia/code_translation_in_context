// Copyright (c) 2019-present, Facebook, Inc.
// All rights reserved.
//
// This source code is licensed under the license found in the
// LICENSE file in the root directory of this source tree.
//

#include <iostream>
#include <cstdlib>
#include <string>
#include <vector>
#include <fstream>
#include <iomanip>
#include <bits/stdc++.h>
using namespace std;
int f_gold ( int n ) {
  if ( n == 0 ) return 0;
  else return 1 + f_gold ( n & ( n - 1 ) );
}


int f_filled ( int n ) {
  return n == 0 ? 0 : 1 + f_filled ( n & ( n - 1 ) ) ;
}

int main() {
    int n_success = 0;
    vector<int> param0 {6,58,90,69,15,54,60,51,46,91};
    for(int i = 0; i < param0.size(); ++i)
    {
        if(f_filled(param0[i]) == f_gold(param0[i]))
        {
            n_success+=1;
        }
    }
    cout << "#Results:" << " " << n_success << ", " << param0.size();
    return 0;
}