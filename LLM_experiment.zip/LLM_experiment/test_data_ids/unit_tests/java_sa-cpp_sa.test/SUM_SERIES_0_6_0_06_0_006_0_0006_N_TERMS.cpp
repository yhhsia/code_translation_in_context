// Copyright (c) 2019-present, Facebook, Inc.
// All rights reserved.
//
// This source code is licensed under the license found in the
// LICENSE file in the root directory of this source tree.
//

#include <iostream>
#include <cstdlib>
#include <string>
#include <vector>
#include <fstream>
#include <iomanip>
#include <bits/stdc++.h>
using namespace std;
float f_gold ( int n ) {
  return ( 0.666 ) * ( 1 - 1 / pow ( 10, n ) );
}


double f_filled ( int n ) {
  return 0.666 * ( 1 - 1 / pow ( 10 , n ) ) ;
}

int main() {
    int n_success = 0;
    vector<int> param0 {1,2,3,4,5,74,77,67,9,12};
    for(int i = 0; i < param0.size(); ++i)
    {
        if(abs(1 - (0.0000001 + abs(f_gold(param0[i])) )/ (abs(f_filled(param0[i])) + 0.0000001)) < 0.001)
        {
            n_success+=1;
        }
    }
    cout << "#Results:" << " " << n_success << ", " << param0.size();
    return 0;
}